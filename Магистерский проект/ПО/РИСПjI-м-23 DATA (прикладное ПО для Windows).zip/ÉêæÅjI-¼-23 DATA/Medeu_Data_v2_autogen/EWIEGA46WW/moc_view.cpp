/****************************************************************************
** Meta object code from reading C++ file 'view.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.3.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../../../Medeu_Data_v2/view.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'view.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.3.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_View_t {
    uint offsetsAndSizes[86];
    char stringdata0[5];
    char stringdata1[27];
    char stringdata2[1];
    char stringdata3[5];
    char stringdata4[26];
    char stringdata5[33];
    char stringdata6[27];
    char stringdata7[34];
    char stringdata8[34];
    char stringdata9[5];
    char stringdata10[31];
    char stringdata11[39];
    char stringdata12[38];
    char stringdata13[31];
    char stringdata14[33];
    char stringdata15[39];
    char stringdata16[6];
    char stringdata17[37];
    char stringdata18[37];
    char stringdata19[34];
    char stringdata20[35];
    char stringdata21[36];
    char stringdata22[36];
    char stringdata23[33];
    char stringdata24[29];
    char stringdata25[10];
    char stringdata26[3];
    char stringdata27[14];
    char stringdata28[17];
    char stringdata29[10];
    char stringdata30[29];
    char stringdata31[12];
    char stringdata32[23];
    char stringdata33[18];
    char stringdata34[4];
    char stringdata35[21];
    char stringdata36[36];
    char stringdata37[6];
    char stringdata38[23];
    char stringdata39[20];
    char stringdata40[6];
    char stringdata41[28];
    char stringdata42[21];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_View_t::offsetsAndSizes) + ofs), len 
static const qt_meta_stringdata_View_t qt_meta_stringdata_View = {
    {
        QT_MOC_LITERAL(0, 4),  // "View"
        QT_MOC_LITERAL(5, 26),  // "signalPathSelectedTransmit"
        QT_MOC_LITERAL(32, 0),  // ""
        QT_MOC_LITERAL(33, 4),  // "path"
        QT_MOC_LITERAL(38, 25),  // "signalPathSelectedReceive"
        QT_MOC_LITERAL(64, 32),  // "slotPushButtonConnection_Clicked"
        QT_MOC_LITERAL(97, 26),  // "slotPushButtonSave_Clicked"
        QT_MOC_LITERAL(124, 33),  // "slotPushButtonMessageSend_Cli..."
        QT_MOC_LITERAL(158, 33),  // "slotPushButtonMessageSend_Set..."
        QT_MOC_LITERAL(192, 4),  // "text"
        QT_MOC_LITERAL(197, 30),  // "slotPushButtonDataSend_SetText"
        QT_MOC_LITERAL(228, 38),  // "slotPushButtonDataToolTransmi..."
        QT_MOC_LITERAL(267, 37),  // "slotPushButtonDataToolReceive..."
        QT_MOC_LITERAL(305, 30),  // "slotPushButtonDataSend_Clicked"
        QT_MOC_LITERAL(336, 32),  // "slotPushButtonDataCancel_Clicked"
        QT_MOC_LITERAL(369, 38),  // "slotComboBoxChannelCurrentInd..."
        QT_MOC_LITERAL(408, 5),  // "index"
        QT_MOC_LITERAL(414, 36),  // "slotComboBoxModemCurrentIndex..."
        QT_MOC_LITERAL(451, 36),  // "slotComboBoxPowerCurrentIndex..."
        QT_MOC_LITERAL(488, 33),  // "slotComboBoxAjCurrentIndexCha..."
        QT_MOC_LITERAL(522, 34),  // "slotComboBoxKeyCurrentIndexCh..."
        QT_MOC_LITERAL(557, 35),  // "slotComboBoxIdRxCurrentIndexC..."
        QT_MOC_LITERAL(593, 35),  // "slotComboBoxIdTxCurrentIndexC..."
        QT_MOC_LITERAL(629, 32),  // "slotLineEditFrequencyTextChanged"
        QT_MOC_LITERAL(662, 28),  // "slotChannelConfiguration_Set"
        QT_MOC_LITERAL(691, 9),  // "channel_t"
        QT_MOC_LITERAL(701, 2),  // "ch"
        QT_MOC_LITERAL(704, 13),  // "slotConnected"
        QT_MOC_LITERAL(718, 16),  // "slotDisconnected"
        QT_MOC_LITERAL(735, 9),  // "slotError"
        QT_MOC_LITERAL(745, 28),  // "QAbstractSocket::SocketError"
        QT_MOC_LITERAL(774, 11),  // "socketError"
        QT_MOC_LITERAL(786, 22),  // "slotMessageBox_SetText"
        QT_MOC_LITERAL(809, 17),  // "QMessageBox::Icon"
        QT_MOC_LITERAL(827, 3),  // "msg"
        QT_MOC_LITERAL(831, 20),  // "slotWaitSpinner_Stop"
        QT_MOC_LITERAL(852, 35),  // "slotProgressBarBattery_valueC..."
        QT_MOC_LITERAL(888, 5),  // "value"
        QT_MOC_LITERAL(894, 22),  // "slotSetStyleSheetColor"
        QT_MOC_LITERAL(917, 19),  // "Model::ProcessState"
        QT_MOC_LITERAL(937, 5),  // "state"
        QT_MOC_LITERAL(943, 27),  // "slotTabWidgetCurrentChanged"
        QT_MOC_LITERAL(971, 20)   // "slotCheckMarkVisible"
    },
    "View",
    "signalPathSelectedTransmit",
    "",
    "path",
    "signalPathSelectedReceive",
    "slotPushButtonConnection_Clicked",
    "slotPushButtonSave_Clicked",
    "slotPushButtonMessageSend_Clicked",
    "slotPushButtonMessageSend_SetText",
    "text",
    "slotPushButtonDataSend_SetText",
    "slotPushButtonDataToolTransmit_Clicked",
    "slotPushButtonDataToolReceive_Clicked",
    "slotPushButtonDataSend_Clicked",
    "slotPushButtonDataCancel_Clicked",
    "slotComboBoxChannelCurrentIndexChanged",
    "index",
    "slotComboBoxModemCurrentIndexChanged",
    "slotComboBoxPowerCurrentIndexChanged",
    "slotComboBoxAjCurrentIndexChanged",
    "slotComboBoxKeyCurrentIndexChanged",
    "slotComboBoxIdRxCurrentIndexChanged",
    "slotComboBoxIdTxCurrentIndexChanged",
    "slotLineEditFrequencyTextChanged",
    "slotChannelConfiguration_Set",
    "channel_t",
    "ch",
    "slotConnected",
    "slotDisconnected",
    "slotError",
    "QAbstractSocket::SocketError",
    "socketError",
    "slotMessageBox_SetText",
    "QMessageBox::Icon",
    "msg",
    "slotWaitSpinner_Stop",
    "slotProgressBarBattery_valueChanged",
    "value",
    "slotSetStyleSheetColor",
    "Model::ProcessState",
    "state",
    "slotTabWidgetCurrentChanged",
    "slotCheckMarkVisible"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_View[] = {

 // content:
      10,       // revision
       0,       // classname
       0,    0, // classinfo
      29,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       2,       // signalCount

 // signals: name, argc, parameters, tag, flags, initial metatype offsets
       1,    1,  188,    2, 0x06,    1 /* Public */,
       4,    1,  191,    2, 0x06,    3 /* Public */,

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       5,    0,  194,    2, 0x08,    5 /* Private */,
       6,    0,  195,    2, 0x08,    6 /* Private */,
       7,    0,  196,    2, 0x08,    7 /* Private */,
       8,    1,  197,    2, 0x08,    8 /* Private */,
      10,    1,  200,    2, 0x08,   10 /* Private */,
      11,    0,  203,    2, 0x08,   12 /* Private */,
      12,    0,  204,    2, 0x08,   13 /* Private */,
      13,    0,  205,    2, 0x08,   14 /* Private */,
      14,    0,  206,    2, 0x08,   15 /* Private */,
      15,    1,  207,    2, 0x08,   16 /* Private */,
      17,    1,  210,    2, 0x08,   18 /* Private */,
      18,    1,  213,    2, 0x08,   20 /* Private */,
      19,    1,  216,    2, 0x08,   22 /* Private */,
      20,    1,  219,    2, 0x08,   24 /* Private */,
      21,    1,  222,    2, 0x08,   26 /* Private */,
      22,    1,  225,    2, 0x08,   28 /* Private */,
      23,    1,  228,    2, 0x08,   30 /* Private */,
      24,    1,  231,    2, 0x08,   32 /* Private */,
      27,    0,  234,    2, 0x08,   34 /* Private */,
      28,    0,  235,    2, 0x08,   35 /* Private */,
      29,    1,  236,    2, 0x08,   36 /* Private */,
      32,    2,  239,    2, 0x08,   38 /* Private */,
      35,    0,  244,    2, 0x08,   41 /* Private */,
      36,    1,  245,    2, 0x08,   42 /* Private */,
      38,    1,  248,    2, 0x08,   44 /* Private */,
      41,    1,  251,    2, 0x08,   46 /* Private */,
      42,    1,  254,    2, 0x08,   48 /* Private */,

 // signals: parameters
    QMetaType::Void, QMetaType::QString,    3,
    QMetaType::Void, QMetaType::QString,    3,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,    9,
    QMetaType::Void, QMetaType::QString,    9,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,   16,
    QMetaType::Void, QMetaType::Int,   16,
    QMetaType::Void, QMetaType::Int,   16,
    QMetaType::Void, QMetaType::Int,   16,
    QMetaType::Void, QMetaType::Int,   16,
    QMetaType::Void, QMetaType::Int,   16,
    QMetaType::Void, QMetaType::Int,   16,
    QMetaType::Void, QMetaType::QString,    9,
    QMetaType::Void, 0x80000000 | 25,   26,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 30,   31,
    QMetaType::Void, 0x80000000 | 33, QMetaType::QString,   34,    9,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,   37,
    QMetaType::Void, 0x80000000 | 39,   40,
    QMetaType::Void, QMetaType::Int,   16,
    QMetaType::Void, QMetaType::UChar,   16,

       0        // eod
};

void View::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<View *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->signalPathSelectedTransmit((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 1: _t->signalPathSelectedReceive((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 2: _t->slotPushButtonConnection_Clicked(); break;
        case 3: _t->slotPushButtonSave_Clicked(); break;
        case 4: _t->slotPushButtonMessageSend_Clicked(); break;
        case 5: _t->slotPushButtonMessageSend_SetText((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 6: _t->slotPushButtonDataSend_SetText((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 7: _t->slotPushButtonDataToolTransmit_Clicked(); break;
        case 8: _t->slotPushButtonDataToolReceive_Clicked(); break;
        case 9: _t->slotPushButtonDataSend_Clicked(); break;
        case 10: _t->slotPushButtonDataCancel_Clicked(); break;
        case 11: _t->slotComboBoxChannelCurrentIndexChanged((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 12: _t->slotComboBoxModemCurrentIndexChanged((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 13: _t->slotComboBoxPowerCurrentIndexChanged((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 14: _t->slotComboBoxAjCurrentIndexChanged((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 15: _t->slotComboBoxKeyCurrentIndexChanged((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 16: _t->slotComboBoxIdRxCurrentIndexChanged((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 17: _t->slotComboBoxIdTxCurrentIndexChanged((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 18: _t->slotLineEditFrequencyTextChanged((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 19: _t->slotChannelConfiguration_Set((*reinterpret_cast< std::add_pointer_t<channel_t>>(_a[1]))); break;
        case 20: _t->slotConnected(); break;
        case 21: _t->slotDisconnected(); break;
        case 22: _t->slotError((*reinterpret_cast< std::add_pointer_t<QAbstractSocket::SocketError>>(_a[1]))); break;
        case 23: _t->slotMessageBox_SetText((*reinterpret_cast< std::add_pointer_t<QMessageBox::Icon>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<QString>>(_a[2]))); break;
        case 24: _t->slotWaitSpinner_Stop(); break;
        case 25: _t->slotProgressBarBattery_valueChanged((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 26: _t->slotSetStyleSheetColor((*reinterpret_cast< std::add_pointer_t<Model::ProcessState>>(_a[1]))); break;
        case 27: _t->slotTabWidgetCurrentChanged((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 28: _t->slotCheckMarkVisible((*reinterpret_cast< std::add_pointer_t<quint8>>(_a[1]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        switch (_id) {
        default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
        case 22:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 0:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< QAbstractSocket::SocketError >(); break;
            }
            break;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (View::*)(const QString & );
            if (_t _q_method = &View::signalPathSelectedTransmit; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (View::*)(const QString & );
            if (_t _q_method = &View::signalPathSelectedReceive; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 1;
                return;
            }
        }
    }
}

const QMetaObject View::staticMetaObject = { {
    QMetaObject::SuperData::link<QMainWindow::staticMetaObject>(),
    qt_meta_stringdata_View.offsetsAndSizes,
    qt_meta_data_View,
    qt_static_metacall,
    nullptr,
qt_incomplete_metaTypeArray<qt_meta_stringdata_View_t
, QtPrivate::TypeAndForceComplete<View, std::true_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<const QString &, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<const QString &, std::false_type>
, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<const QString &, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<const QString &, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<int, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<int, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<int, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<int, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<int, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<int, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<int, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<const QString &, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<const channel_t &, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<QAbstractSocket::SocketError, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<QMessageBox::Icon, std::false_type>, QtPrivate::TypeAndForceComplete<QString, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<int, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<Model::ProcessState, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<int, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<quint8, std::false_type>


>,
    nullptr
} };


const QMetaObject *View::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *View::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_View.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int View::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 29)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 29;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 29)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 29;
    }
    return _id;
}

// SIGNAL 0
void View::signalPathSelectedTransmit(const QString & _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void View::signalPathSelectedReceive(const QString & _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
