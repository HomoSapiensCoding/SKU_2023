/****************************************************************************
** Meta object code from reading C++ file 'model.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.3.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../../../Medeu_Data_v2/model.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'model.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.3.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_Model_t {
    uint offsetsAndSizes[168];
    char stringdata0[6];
    char stringdata1[26];
    char stringdata2[1];
    char stringdata3[25];
    char stringdata4[18];
    char stringdata5[4];
    char stringdata6[5];
    char stringdata7[31];
    char stringdata8[10];
    char stringdata9[3];
    char stringdata10[23];
    char stringdata11[29];
    char stringdata12[25];
    char stringdata13[28];
    char stringdata14[30];
    char stringdata15[39];
    char stringdata16[38];
    char stringdata17[38];
    char stringdata18[32];
    char stringdata19[36];
    char stringdata20[36];
    char stringdata21[33];
    char stringdata22[38];
    char stringdata23[6];
    char stringdata24[34];
    char stringdata25[31];
    char stringdata26[25];
    char stringdata27[20];
    char stringdata28[6];
    char stringdata29[23];
    char stringdata30[6];
    char stringdata31[14];
    char stringdata32[14];
    char stringdata33[17];
    char stringdata34[10];
    char stringdata35[29];
    char stringdata36[12];
    char stringdata37[24];
    char stringdata38[26];
    char stringdata39[23];
    char stringdata40[23];
    char stringdata41[20];
    char stringdata42[18];
    char stringdata43[24];
    char stringdata44[24];
    char stringdata45[5];
    char stringdata46[23];
    char stringdata47[11];
    char stringdata48[8];
    char stringdata49[5];
    char stringdata50[8];
    char stringdata51[9];
    char stringdata52[12];
    char stringdata53[12];
    char stringdata54[11];
    char stringdata55[20];
    char stringdata56[11];
    char stringdata57[10];
    char stringdata58[12];
    char stringdata59[11];
    char stringdata60[10];
    char stringdata61[11];
    char stringdata62[6];
    char stringdata63[18];
    char stringdata64[13];
    char stringdata65[13];
    char stringdata66[33];
    char stringdata67[32];
    char stringdata68[25];
    char stringdata69[24];
    char stringdata70[30];
    char stringdata71[29];
    char stringdata72[31];
    char stringdata73[30];
    char stringdata74[22];
    char stringdata75[21];
    char stringdata76[24];
    char stringdata77[6];
    char stringdata78[18];
    char stringdata79[19];
    char stringdata80[19];
    char stringdata81[22];
    char stringdata82[22];
    char stringdata83[22];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_Model_t::offsetsAndSizes) + ofs), len 
static const qt_meta_stringdata_Model_t qt_meta_stringdata_Model = {
    {
        QT_MOC_LITERAL(0, 5),  // "Model"
        QT_MOC_LITERAL(6, 25),  // "signalTimerTimeoutConnect"
        QT_MOC_LITERAL(32, 0),  // ""
        QT_MOC_LITERAL(33, 24),  // "signalMessageBox_SetText"
        QT_MOC_LITERAL(58, 17),  // "QMessageBox::Icon"
        QT_MOC_LITERAL(76, 3),  // "msg"
        QT_MOC_LITERAL(80, 4),  // "text"
        QT_MOC_LITERAL(85, 30),  // "signalChannelConfiguration_Set"
        QT_MOC_LITERAL(116, 9),  // "channel_t"
        QT_MOC_LITERAL(126, 2),  // "ch"
        QT_MOC_LITERAL(129, 22),  // "signalWaitSpinner_Stop"
        QT_MOC_LITERAL(152, 28),  // "signalTextEditMessage_Append"
        QT_MOC_LITERAL(181, 24),  // "signalTextEditLog_Append"
        QT_MOC_LITERAL(206, 27),  // "signalLineEditSpeed_SetText"
        QT_MOC_LITERAL(234, 29),  // "signalLineEditProcess_SetText"
        QT_MOC_LITERAL(264, 38),  // "signalLineEditFileSizeTransmi..."
        QT_MOC_LITERAL(303, 37),  // "signalLineEditFileSizeReceive..."
        QT_MOC_LITERAL(341, 37),  // "signalLineEditFileNameReceive..."
        QT_MOC_LITERAL(379, 31),  // "signalLineEditBytesSent_SetText"
        QT_MOC_LITERAL(411, 35),  // "signalLineEditBytesReceived_S..."
        QT_MOC_LITERAL(447, 35),  // "signalPushButtonMessageSend_S..."
        QT_MOC_LITERAL(483, 32),  // "signalPushButtonDataSend_SetText"
        QT_MOC_LITERAL(516, 37),  // "signalProgressBarMessageSend_..."
        QT_MOC_LITERAL(554, 5),  // "value"
        QT_MOC_LITERAL(560, 33),  // "signalProgressBarBattery_SetV..."
        QT_MOC_LITERAL(594, 30),  // "signalProgressBarBattery_Reset"
        QT_MOC_LITERAL(625, 24),  // "signalSetStyleSheetColor"
        QT_MOC_LITERAL(650, 19),  // "Model::ProcessState"
        QT_MOC_LITERAL(670, 5),  // "state"
        QT_MOC_LITERAL(676, 22),  // "signalCheckMarkVisible"
        QT_MOC_LITERAL(699, 5),  // "index"
        QT_MOC_LITERAL(705, 13),  // "slotReadyRead"
        QT_MOC_LITERAL(719, 13),  // "slotConnected"
        QT_MOC_LITERAL(733, 16),  // "slotDisconnected"
        QT_MOC_LITERAL(750, 9),  // "slotError"
        QT_MOC_LITERAL(760, 28),  // "QAbstractSocket::SocketError"
        QT_MOC_LITERAL(789, 11),  // "socketError"
        QT_MOC_LITERAL(801, 23),  // "slotTimerTimeoutConnect"
        QT_MOC_LITERAL(825, 25),  // "slotTimerTimeoutKeepAlive"
        QT_MOC_LITERAL(851, 22),  // "slotTimerResendRequest"
        QT_MOC_LITERAL(874, 22),  // "slotTimerResendMessage"
        QT_MOC_LITERAL(897, 19),  // "slotTimerResendData"
        QT_MOC_LITERAL(917, 17),  // "slotTimerSetSpeed"
        QT_MOC_LITERAL(935, 23),  // "slotTimerMessageTimeout"
        QT_MOC_LITERAL(959, 23),  // "slotSetPathFileTransmit"
        QT_MOC_LITERAL(983, 4),  // "path"
        QT_MOC_LITERAL(988, 22),  // "slotSetPathFileReceive"
        QT_MOC_LITERAL(1011, 10),  // "TypePacket"
        QT_MOC_LITERAL(1022, 7),  // "MESSAGE"
        QT_MOC_LITERAL(1030, 4),  // "DATA"
        QT_MOC_LITERAL(1035, 7),  // "REQUEST"
        QT_MOC_LITERAL(1043, 8),  // "RESPONSE"
        QT_MOC_LITERAL(1052, 11),  // "GET_CHANNEL"
        QT_MOC_LITERAL(1064, 11),  // "SET_CHANNEL"
        QT_MOC_LITERAL(1076, 10),  // "WR_CHANNEL"
        QT_MOC_LITERAL(1087, 19),  // "GET_WORKING_CHANNEL"
        QT_MOC_LITERAL(1107, 10),  // "GET_TAB_AJ"
        QT_MOC_LITERAL(1118, 9),  // "WR_TAB_AJ"
        QT_MOC_LITERAL(1128, 11),  // "GET_KEY_AES"
        QT_MOC_LITERAL(1140, 10),  // "WR_KEY_AES"
        QT_MOC_LITERAL(1151, 9),  // "SET_SPEED"
        QT_MOC_LITERAL(1161, 10),  // "SUCCESSFUL"
        QT_MOC_LITERAL(1172, 5),  // "ERROR"
        QT_MOC_LITERAL(1178, 17),  // "GET_BATTERY_VALUE"
        QT_MOC_LITERAL(1196, 12),  // "ProcessState"
        QT_MOC_LITERAL(1209, 12),  // "PROCESS_IDLE"
        QT_MOC_LITERAL(1222, 32),  // "PROCESS_MESSAGE_REQUEST_TRANSMIT"
        QT_MOC_LITERAL(1255, 31),  // "PROCESS_MESSAGE_REQUEST_RECEIVE"
        QT_MOC_LITERAL(1287, 24),  // "PROCESS_MESSAGE_TRANSMIT"
        QT_MOC_LITERAL(1312, 23),  // "PROCESS_MESSAGE_RECEIVE"
        QT_MOC_LITERAL(1336, 29),  // "PROCESS_DATA_REQUEST_TRANSMIT"
        QT_MOC_LITERAL(1366, 28),  // "PROCESS_DATA_REQUEST_RECEIVE"
        QT_MOC_LITERAL(1395, 30),  // "PROCESS_DATA_FILENAME_TRANSMIT"
        QT_MOC_LITERAL(1426, 29),  // "PROCESS_DATA_FILENAME_RECEIVE"
        QT_MOC_LITERAL(1456, 21),  // "PROCESS_DATA_TRANSMIT"
        QT_MOC_LITERAL(1478, 20),  // "PROCESS_DATA_RECEIVE"
        QT_MOC_LITERAL(1499, 23),  // "PROCESS_DATA_DISCONNECT"
        QT_MOC_LITERAL(1523, 5),  // "Speed"
        QT_MOC_LITERAL(1529, 17),  // "SPEED_FSK_50_KBPS"
        QT_MOC_LITERAL(1547, 18),  // "SPEED_FSK_125_KBPS"
        QT_MOC_LITERAL(1566, 18),  // "SPEED_FSK_250_KBPS"
        QT_MOC_LITERAL(1585, 21),  // "SPEED_LORA_3_125_KBPS"
        QT_MOC_LITERAL(1607, 21),  // "SPEED_LORA_5_468_KBPS"
        QT_MOC_LITERAL(1629, 21)   // "SPEED_LORA_9_375_KBPS"
    },
    "Model",
    "signalTimerTimeoutConnect",
    "",
    "signalMessageBox_SetText",
    "QMessageBox::Icon",
    "msg",
    "text",
    "signalChannelConfiguration_Set",
    "channel_t",
    "ch",
    "signalWaitSpinner_Stop",
    "signalTextEditMessage_Append",
    "signalTextEditLog_Append",
    "signalLineEditSpeed_SetText",
    "signalLineEditProcess_SetText",
    "signalLineEditFileSizeTransmit_SetText",
    "signalLineEditFileSizeReceive_SetText",
    "signalLineEditFileNameReceive_SetText",
    "signalLineEditBytesSent_SetText",
    "signalLineEditBytesReceived_SetText",
    "signalPushButtonMessageSend_SetText",
    "signalPushButtonDataSend_SetText",
    "signalProgressBarMessageSend_SetValue",
    "value",
    "signalProgressBarBattery_SetValue",
    "signalProgressBarBattery_Reset",
    "signalSetStyleSheetColor",
    "Model::ProcessState",
    "state",
    "signalCheckMarkVisible",
    "index",
    "slotReadyRead",
    "slotConnected",
    "slotDisconnected",
    "slotError",
    "QAbstractSocket::SocketError",
    "socketError",
    "slotTimerTimeoutConnect",
    "slotTimerTimeoutKeepAlive",
    "slotTimerResendRequest",
    "slotTimerResendMessage",
    "slotTimerResendData",
    "slotTimerSetSpeed",
    "slotTimerMessageTimeout",
    "slotSetPathFileTransmit",
    "path",
    "slotSetPathFileReceive",
    "TypePacket",
    "MESSAGE",
    "DATA",
    "REQUEST",
    "RESPONSE",
    "GET_CHANNEL",
    "SET_CHANNEL",
    "WR_CHANNEL",
    "GET_WORKING_CHANNEL",
    "GET_TAB_AJ",
    "WR_TAB_AJ",
    "GET_KEY_AES",
    "WR_KEY_AES",
    "SET_SPEED",
    "SUCCESSFUL",
    "ERROR",
    "GET_BATTERY_VALUE",
    "ProcessState",
    "PROCESS_IDLE",
    "PROCESS_MESSAGE_REQUEST_TRANSMIT",
    "PROCESS_MESSAGE_REQUEST_RECEIVE",
    "PROCESS_MESSAGE_TRANSMIT",
    "PROCESS_MESSAGE_RECEIVE",
    "PROCESS_DATA_REQUEST_TRANSMIT",
    "PROCESS_DATA_REQUEST_RECEIVE",
    "PROCESS_DATA_FILENAME_TRANSMIT",
    "PROCESS_DATA_FILENAME_RECEIVE",
    "PROCESS_DATA_TRANSMIT",
    "PROCESS_DATA_RECEIVE",
    "PROCESS_DATA_DISCONNECT",
    "Speed",
    "SPEED_FSK_50_KBPS",
    "SPEED_FSK_125_KBPS",
    "SPEED_FSK_250_KBPS",
    "SPEED_LORA_3_125_KBPS",
    "SPEED_LORA_5_468_KBPS",
    "SPEED_LORA_9_375_KBPS"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_Model[] = {

 // content:
      10,       // revision
       0,       // classname
       0,    0, // classinfo
      33,   14, // methods
       0,    0, // properties
       3,  287, // enums/sets
       0,    0, // constructors
       0,       // flags
      20,       // signalCount

 // signals: name, argc, parameters, tag, flags, initial metatype offsets
       1,    0,  212,    2, 0x06,    1 /* Public */,
       3,    2,  213,    2, 0x06,    2 /* Public */,
       7,    1,  218,    2, 0x06,    5 /* Public */,
      10,    0,  221,    2, 0x06,    7 /* Public */,
      11,    1,  222,    2, 0x06,    8 /* Public */,
      12,    1,  225,    2, 0x06,   10 /* Public */,
      13,    1,  228,    2, 0x06,   12 /* Public */,
      14,    1,  231,    2, 0x06,   14 /* Public */,
      15,    1,  234,    2, 0x06,   16 /* Public */,
      16,    1,  237,    2, 0x06,   18 /* Public */,
      17,    1,  240,    2, 0x06,   20 /* Public */,
      18,    1,  243,    2, 0x06,   22 /* Public */,
      19,    1,  246,    2, 0x06,   24 /* Public */,
      20,    1,  249,    2, 0x06,   26 /* Public */,
      21,    1,  252,    2, 0x06,   28 /* Public */,
      22,    1,  255,    2, 0x06,   30 /* Public */,
      24,    1,  258,    2, 0x06,   32 /* Public */,
      25,    0,  261,    2, 0x06,   34 /* Public */,
      26,    1,  262,    2, 0x06,   35 /* Public */,
      29,    1,  265,    2, 0x06,   37 /* Public */,

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
      31,    0,  268,    2, 0x08,   39 /* Private */,
      32,    0,  269,    2, 0x08,   40 /* Private */,
      33,    0,  270,    2, 0x08,   41 /* Private */,
      34,    1,  271,    2, 0x08,   42 /* Private */,
      37,    0,  274,    2, 0x08,   44 /* Private */,
      38,    0,  275,    2, 0x08,   45 /* Private */,
      39,    0,  276,    2, 0x08,   46 /* Private */,
      40,    0,  277,    2, 0x08,   47 /* Private */,
      41,    0,  278,    2, 0x08,   48 /* Private */,
      42,    0,  279,    2, 0x08,   49 /* Private */,
      43,    0,  280,    2, 0x08,   50 /* Private */,
      44,    1,  281,    2, 0x0a,   51 /* Public */,
      46,    1,  284,    2, 0x0a,   53 /* Public */,

 // signals: parameters
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 4, QMetaType::QString,    5,    6,
    QMetaType::Void, 0x80000000 | 8,    9,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,    6,
    QMetaType::Void, QMetaType::QString,    6,
    QMetaType::Void, QMetaType::QString,    6,
    QMetaType::Void, QMetaType::QString,    6,
    QMetaType::Void, QMetaType::QString,    6,
    QMetaType::Void, QMetaType::QString,    6,
    QMetaType::Void, QMetaType::QString,    6,
    QMetaType::Void, QMetaType::QString,    6,
    QMetaType::Void, QMetaType::QString,    6,
    QMetaType::Void, QMetaType::QString,    6,
    QMetaType::Void, QMetaType::QString,    6,
    QMetaType::Void, QMetaType::Int,   23,
    QMetaType::Void, QMetaType::Int,   23,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 27,   28,
    QMetaType::Void, QMetaType::UChar,   30,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 35,   36,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,   45,
    QMetaType::Void, QMetaType::QString,   45,

 // enums: name, alias, flags, count, data
      47,   47, 0x0,   16,  302,
      64,   64, 0x0,   12,  334,
      77,   77, 0x0,    6,  358,

 // enum data: key, value
      48, uint(Model::MESSAGE),
      49, uint(Model::DATA),
      50, uint(Model::REQUEST),
      51, uint(Model::RESPONSE),
      52, uint(Model::GET_CHANNEL),
      53, uint(Model::SET_CHANNEL),
      54, uint(Model::WR_CHANNEL),
      55, uint(Model::GET_WORKING_CHANNEL),
      56, uint(Model::GET_TAB_AJ),
      57, uint(Model::WR_TAB_AJ),
      58, uint(Model::GET_KEY_AES),
      59, uint(Model::WR_KEY_AES),
      60, uint(Model::SET_SPEED),
      61, uint(Model::SUCCESSFUL),
      62, uint(Model::ERROR),
      63, uint(Model::GET_BATTERY_VALUE),
      65, uint(Model::PROCESS_IDLE),
      66, uint(Model::PROCESS_MESSAGE_REQUEST_TRANSMIT),
      67, uint(Model::PROCESS_MESSAGE_REQUEST_RECEIVE),
      68, uint(Model::PROCESS_MESSAGE_TRANSMIT),
      69, uint(Model::PROCESS_MESSAGE_RECEIVE),
      70, uint(Model::PROCESS_DATA_REQUEST_TRANSMIT),
      71, uint(Model::PROCESS_DATA_REQUEST_RECEIVE),
      72, uint(Model::PROCESS_DATA_FILENAME_TRANSMIT),
      73, uint(Model::PROCESS_DATA_FILENAME_RECEIVE),
      74, uint(Model::PROCESS_DATA_TRANSMIT),
      75, uint(Model::PROCESS_DATA_RECEIVE),
      76, uint(Model::PROCESS_DATA_DISCONNECT),
      78, uint(Model::SPEED_FSK_50_KBPS),
      79, uint(Model::SPEED_FSK_125_KBPS),
      80, uint(Model::SPEED_FSK_250_KBPS),
      81, uint(Model::SPEED_LORA_3_125_KBPS),
      82, uint(Model::SPEED_LORA_5_468_KBPS),
      83, uint(Model::SPEED_LORA_9_375_KBPS),

       0        // eod
};

void Model::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<Model *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->signalTimerTimeoutConnect(); break;
        case 1: _t->signalMessageBox_SetText((*reinterpret_cast< std::add_pointer_t<QMessageBox::Icon>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<QString>>(_a[2]))); break;
        case 2: _t->signalChannelConfiguration_Set((*reinterpret_cast< std::add_pointer_t<channel_t>>(_a[1]))); break;
        case 3: _t->signalWaitSpinner_Stop(); break;
        case 4: _t->signalTextEditMessage_Append((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 5: _t->signalTextEditLog_Append((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 6: _t->signalLineEditSpeed_SetText((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 7: _t->signalLineEditProcess_SetText((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 8: _t->signalLineEditFileSizeTransmit_SetText((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 9: _t->signalLineEditFileSizeReceive_SetText((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 10: _t->signalLineEditFileNameReceive_SetText((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 11: _t->signalLineEditBytesSent_SetText((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 12: _t->signalLineEditBytesReceived_SetText((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 13: _t->signalPushButtonMessageSend_SetText((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 14: _t->signalPushButtonDataSend_SetText((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 15: _t->signalProgressBarMessageSend_SetValue((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 16: _t->signalProgressBarBattery_SetValue((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 17: _t->signalProgressBarBattery_Reset(); break;
        case 18: _t->signalSetStyleSheetColor((*reinterpret_cast< std::add_pointer_t<Model::ProcessState>>(_a[1]))); break;
        case 19: _t->signalCheckMarkVisible((*reinterpret_cast< std::add_pointer_t<quint8>>(_a[1]))); break;
        case 20: _t->slotReadyRead(); break;
        case 21: _t->slotConnected(); break;
        case 22: _t->slotDisconnected(); break;
        case 23: _t->slotError((*reinterpret_cast< std::add_pointer_t<QAbstractSocket::SocketError>>(_a[1]))); break;
        case 24: _t->slotTimerTimeoutConnect(); break;
        case 25: _t->slotTimerTimeoutKeepAlive(); break;
        case 26: _t->slotTimerResendRequest(); break;
        case 27: _t->slotTimerResendMessage(); break;
        case 28: _t->slotTimerResendData(); break;
        case 29: _t->slotTimerSetSpeed(); break;
        case 30: _t->slotTimerMessageTimeout(); break;
        case 31: _t->slotSetPathFileTransmit((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 32: _t->slotSetPathFileReceive((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        switch (_id) {
        default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
        case 23:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 0:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< QAbstractSocket::SocketError >(); break;
            }
            break;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (Model::*)();
            if (_t _q_method = &Model::signalTimerTimeoutConnect; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (Model::*)(QMessageBox::Icon , QString );
            if (_t _q_method = &Model::signalMessageBox_SetText; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (Model::*)(const channel_t & );
            if (_t _q_method = &Model::signalChannelConfiguration_Set; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 2;
                return;
            }
        }
        {
            using _t = void (Model::*)();
            if (_t _q_method = &Model::signalWaitSpinner_Stop; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 3;
                return;
            }
        }
        {
            using _t = void (Model::*)(const QString & );
            if (_t _q_method = &Model::signalTextEditMessage_Append; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 4;
                return;
            }
        }
        {
            using _t = void (Model::*)(const QString & );
            if (_t _q_method = &Model::signalTextEditLog_Append; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 5;
                return;
            }
        }
        {
            using _t = void (Model::*)(const QString & );
            if (_t _q_method = &Model::signalLineEditSpeed_SetText; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 6;
                return;
            }
        }
        {
            using _t = void (Model::*)(const QString & );
            if (_t _q_method = &Model::signalLineEditProcess_SetText; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 7;
                return;
            }
        }
        {
            using _t = void (Model::*)(const QString & );
            if (_t _q_method = &Model::signalLineEditFileSizeTransmit_SetText; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 8;
                return;
            }
        }
        {
            using _t = void (Model::*)(const QString & );
            if (_t _q_method = &Model::signalLineEditFileSizeReceive_SetText; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 9;
                return;
            }
        }
        {
            using _t = void (Model::*)(const QString & );
            if (_t _q_method = &Model::signalLineEditFileNameReceive_SetText; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 10;
                return;
            }
        }
        {
            using _t = void (Model::*)(const QString & );
            if (_t _q_method = &Model::signalLineEditBytesSent_SetText; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 11;
                return;
            }
        }
        {
            using _t = void (Model::*)(const QString & );
            if (_t _q_method = &Model::signalLineEditBytesReceived_SetText; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 12;
                return;
            }
        }
        {
            using _t = void (Model::*)(const QString & );
            if (_t _q_method = &Model::signalPushButtonMessageSend_SetText; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 13;
                return;
            }
        }
        {
            using _t = void (Model::*)(const QString & );
            if (_t _q_method = &Model::signalPushButtonDataSend_SetText; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 14;
                return;
            }
        }
        {
            using _t = void (Model::*)(int );
            if (_t _q_method = &Model::signalProgressBarMessageSend_SetValue; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 15;
                return;
            }
        }
        {
            using _t = void (Model::*)(int );
            if (_t _q_method = &Model::signalProgressBarBattery_SetValue; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 16;
                return;
            }
        }
        {
            using _t = void (Model::*)();
            if (_t _q_method = &Model::signalProgressBarBattery_Reset; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 17;
                return;
            }
        }
        {
            using _t = void (Model::*)(Model::ProcessState );
            if (_t _q_method = &Model::signalSetStyleSheetColor; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 18;
                return;
            }
        }
        {
            using _t = void (Model::*)(quint8 );
            if (_t _q_method = &Model::signalCheckMarkVisible; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 19;
                return;
            }
        }
    }
}

const QMetaObject Model::staticMetaObject = { {
    QMetaObject::SuperData::link<QTcpSocket::staticMetaObject>(),
    qt_meta_stringdata_Model.offsetsAndSizes,
    qt_meta_data_Model,
    qt_static_metacall,
    nullptr,
qt_incomplete_metaTypeArray<qt_meta_stringdata_Model_t
, QtPrivate::TypeAndForceComplete<Model, std::true_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<QMessageBox::Icon, std::false_type>, QtPrivate::TypeAndForceComplete<QString, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<const channel_t &, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<const QString &, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<const QString &, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<const QString &, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<const QString &, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<const QString &, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<const QString &, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<const QString &, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<const QString &, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<const QString &, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<const QString &, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<const QString &, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<int, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<int, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<Model::ProcessState, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<quint8, std::false_type>
, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<QAbstractSocket::SocketError, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<const QString &, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<const QString &, std::false_type>


>,
    nullptr
} };


const QMetaObject *Model::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *Model::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_Model.stringdata0))
        return static_cast<void*>(this);
    return QTcpSocket::qt_metacast(_clname);
}

int Model::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QTcpSocket::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 33)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 33;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 33)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 33;
    }
    return _id;
}

// SIGNAL 0
void Model::signalTimerTimeoutConnect()
{
    QMetaObject::activate(this, &staticMetaObject, 0, nullptr);
}

// SIGNAL 1
void Model::signalMessageBox_SetText(QMessageBox::Icon _t1, QString _t2)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void Model::signalChannelConfiguration_Set(const channel_t & _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}

// SIGNAL 3
void Model::signalWaitSpinner_Stop()
{
    QMetaObject::activate(this, &staticMetaObject, 3, nullptr);
}

// SIGNAL 4
void Model::signalTextEditMessage_Append(const QString & _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 4, _a);
}

// SIGNAL 5
void Model::signalTextEditLog_Append(const QString & _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 5, _a);
}

// SIGNAL 6
void Model::signalLineEditSpeed_SetText(const QString & _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 6, _a);
}

// SIGNAL 7
void Model::signalLineEditProcess_SetText(const QString & _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 7, _a);
}

// SIGNAL 8
void Model::signalLineEditFileSizeTransmit_SetText(const QString & _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 8, _a);
}

// SIGNAL 9
void Model::signalLineEditFileSizeReceive_SetText(const QString & _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 9, _a);
}

// SIGNAL 10
void Model::signalLineEditFileNameReceive_SetText(const QString & _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 10, _a);
}

// SIGNAL 11
void Model::signalLineEditBytesSent_SetText(const QString & _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 11, _a);
}

// SIGNAL 12
void Model::signalLineEditBytesReceived_SetText(const QString & _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 12, _a);
}

// SIGNAL 13
void Model::signalPushButtonMessageSend_SetText(const QString & _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 13, _a);
}

// SIGNAL 14
void Model::signalPushButtonDataSend_SetText(const QString & _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 14, _a);
}

// SIGNAL 15
void Model::signalProgressBarMessageSend_SetValue(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 15, _a);
}

// SIGNAL 16
void Model::signalProgressBarBattery_SetValue(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 16, _a);
}

// SIGNAL 17
void Model::signalProgressBarBattery_Reset()
{
    QMetaObject::activate(this, &staticMetaObject, 17, nullptr);
}

// SIGNAL 18
void Model::signalSetStyleSheetColor(Model::ProcessState _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 18, _a);
}

// SIGNAL 19
void Model::signalCheckMarkVisible(quint8 _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 19, _a);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
