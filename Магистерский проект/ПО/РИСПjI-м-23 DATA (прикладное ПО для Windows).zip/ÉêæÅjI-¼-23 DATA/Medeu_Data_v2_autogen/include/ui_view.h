/********************************************************************************
** Form generated from reading UI file 'view.ui'
**
** Created by: Qt User Interface Compiler version 6.3.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_VIEW_H
#define UI_VIEW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QFrame>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QProgressBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QRadioButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QTabWidget>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QWidget>
#include "my_widget/ipctrl.h"

QT_BEGIN_NAMESPACE

class Ui_View
{
public:
    QWidget *centralwidget;
    QGridLayout *gridLayout;
    QFrame *line_5;
    QTabWidget *tabWidget;
    QWidget *tab;
    QGridLayout *gridLayout_4;
    QLineEdit *lineEditFileNameReceive;
    QLabel *labelDataTansmit;
    QPushButton *pushButtonDataCancel;
    QLabel *labelFileSizeTransmit;
    QLabel *labelBytesSent;
    QPushButton *pushButtonDataToolTransmit;
    QTextEdit *textEditLog;
    QLineEdit *lineEditPathReceive;
    QLineEdit *lineEditBytesSent;
    QPushButton *pushButtonDataSend;
    QLineEdit *lineEditFileSizeReceive;
    QLabel *labelFileSizeReceive;
    QLabel *labelPathTransmit;
    QLineEdit *lineEditPathTransmit;
    QLabel *labelFileNameReseive;
    QLabel *labelDataReceive;
    QLabel *labelPathReceive;
    QFrame *line_3;
    QFrame *line_4;
    QLabel *labelLog;
    QLineEdit *lineEditFileSizeTransmit;
    QSpacerItem *verticalSpacer_3;
    QSpacerItem *verticalSpacer_2;
    QPushButton *pushButtonDataToolReceive;
    QLineEdit *lineEditBytesReceived;
    QLabel *labelBytesReceived;
    QWidget *tab_2;
    QGridLayout *gridLayout_2;
    QPushButton *pushButtonMessageSend;
    QTextEdit *textEditMessage;
    QLineEdit *lineEditMessageSend;
    QPushButton *pushButtonClear;
    QGridLayout *gridLayout_3;
    QPushButton *pushButtonSave;
    QLabel *labelChannel;
    QLabel *labelIdRx;
    QComboBox *comboBoxIdTx;
    QComboBox *comboBoxModem;
    QLabel *labelChannelConfig;
    QLabel *labelIdTx;
    QComboBox *comboBoxIdRx;
    QLabel *labelBattery;
    QRadioButton *radioButtonStateConnect;
    QLabel *labelModem;
    QLabel *labelAj;
    QComboBox *comboBoxMode;
    QLabel *labelFrequency;
    QLabel *labelMode;
    QFrame *line_2;
    QFrame *line_6;
    IPCtrl *inputIp;
    QComboBox *comboBoxChannel;
    QProgressBar *progressBar;
    QFrame *line;
    QLabel *labelPower;
    QComboBox *comboBoxPower;
    QLineEdit *lineEditProcess;
    QLineEdit *lineEditFrequency;
    QProgressBar *progressBarBattery;
    QLabel *labelKHZ;
    QLabel *labelKey;
    QComboBox *comboBoxKey;
    QPushButton *pushButtonConnect;
    QComboBox *comboBoxAj;
    QLineEdit *lineEditSpeed;
    QSpacerItem *verticalSpacer;

    void setupUi(QMainWindow *View)
    {
        if (View->objectName().isEmpty())
            View->setObjectName(QString::fromUtf8("View"));
        View->resize(1024, 700);
        View->setStyleSheet(QString::fromUtf8("font: 10pt \"Segoe UI\";"));
        centralwidget = new QWidget(View);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        gridLayout = new QGridLayout(centralwidget);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        line_5 = new QFrame(centralwidget);
        line_5->setObjectName(QString::fromUtf8("line_5"));
        line_5->setFrameShape(QFrame::HLine);
        line_5->setFrameShadow(QFrame::Sunken);

        gridLayout->addWidget(line_5, 2, 0, 1, 2);

        tabWidget = new QTabWidget(centralwidget);
        tabWidget->setObjectName(QString::fromUtf8("tabWidget"));
        tabWidget->setStyleSheet(QString::fromUtf8("QTabBar::tab \n"
"{ \n"
"width: 150px; \n"
"\n"
"} \n"
"QTabWidget::tab-bar \n"
"{\n"
"alignment: center;\n"
"}"));
        tab = new QWidget();
        tab->setObjectName(QString::fromUtf8("tab"));
        gridLayout_4 = new QGridLayout(tab);
        gridLayout_4->setObjectName(QString::fromUtf8("gridLayout_4"));
        lineEditFileNameReceive = new QLineEdit(tab);
        lineEditFileNameReceive->setObjectName(QString::fromUtf8("lineEditFileNameReceive"));
        QSizePolicy sizePolicy(QSizePolicy::Expanding, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(lineEditFileNameReceive->sizePolicy().hasHeightForWidth());
        lineEditFileNameReceive->setSizePolicy(sizePolicy);
        lineEditFileNameReceive->setReadOnly(true);

        gridLayout_4->addWidget(lineEditFileNameReceive, 8, 2, 1, 1);

        labelDataTansmit = new QLabel(tab);
        labelDataTansmit->setObjectName(QString::fromUtf8("labelDataTansmit"));
        sizePolicy.setHeightForWidth(labelDataTansmit->sizePolicy().hasHeightForWidth());
        labelDataTansmit->setSizePolicy(sizePolicy);
        labelDataTansmit->setAlignment(Qt::AlignCenter);

        gridLayout_4->addWidget(labelDataTansmit, 0, 0, 1, 5);

        pushButtonDataCancel = new QPushButton(tab);
        pushButtonDataCancel->setObjectName(QString::fromUtf8("pushButtonDataCancel"));
        QSizePolicy sizePolicy1(QSizePolicy::Fixed, QSizePolicy::Preferred);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(pushButtonDataCancel->sizePolicy().hasHeightForWidth());
        pushButtonDataCancel->setSizePolicy(sizePolicy1);
        pushButtonDataCancel->setMinimumSize(QSize(100, 0));

        gridLayout_4->addWidget(pushButtonDataCancel, 7, 4, 1, 1);

        labelFileSizeTransmit = new QLabel(tab);
        labelFileSizeTransmit->setObjectName(QString::fromUtf8("labelFileSizeTransmit"));
        QSizePolicy sizePolicy2(QSizePolicy::Preferred, QSizePolicy::Fixed);
        sizePolicy2.setHorizontalStretch(0);
        sizePolicy2.setVerticalStretch(0);
        sizePolicy2.setHeightForWidth(labelFileSizeTransmit->sizePolicy().hasHeightForWidth());
        labelFileSizeTransmit->setSizePolicy(sizePolicy2);

        gridLayout_4->addWidget(labelFileSizeTransmit, 2, 0, 1, 1);

        labelBytesSent = new QLabel(tab);
        labelBytesSent->setObjectName(QString::fromUtf8("labelBytesSent"));

        gridLayout_4->addWidget(labelBytesSent, 3, 0, 1, 1);

        pushButtonDataToolTransmit = new QPushButton(tab);
        pushButtonDataToolTransmit->setObjectName(QString::fromUtf8("pushButtonDataToolTransmit"));
        sizePolicy1.setHeightForWidth(pushButtonDataToolTransmit->sizePolicy().hasHeightForWidth());
        pushButtonDataToolTransmit->setSizePolicy(sizePolicy1);
        pushButtonDataToolTransmit->setMinimumSize(QSize(50, 0));

        gridLayout_4->addWidget(pushButtonDataToolTransmit, 1, 3, 1, 1);

        textEditLog = new QTextEdit(tab);
        textEditLog->setObjectName(QString::fromUtf8("textEditLog"));
        textEditLog->setTextInteractionFlags(Qt::NoTextInteraction);

        gridLayout_4->addWidget(textEditLog, 15, 0, 1, 5);

        lineEditPathReceive = new QLineEdit(tab);
        lineEditPathReceive->setObjectName(QString::fromUtf8("lineEditPathReceive"));
        lineEditPathReceive->setReadOnly(true);

        gridLayout_4->addWidget(lineEditPathReceive, 7, 2, 1, 1);

        lineEditBytesSent = new QLineEdit(tab);
        lineEditBytesSent->setObjectName(QString::fromUtf8("lineEditBytesSent"));
        QSizePolicy sizePolicy3(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy3.setHorizontalStretch(0);
        sizePolicy3.setVerticalStretch(0);
        sizePolicy3.setHeightForWidth(lineEditBytesSent->sizePolicy().hasHeightForWidth());
        lineEditBytesSent->setSizePolicy(sizePolicy3);
        lineEditBytesSent->setMinimumSize(QSize(200, 0));
        lineEditBytesSent->setReadOnly(true);

        gridLayout_4->addWidget(lineEditBytesSent, 3, 2, 1, 1);

        pushButtonDataSend = new QPushButton(tab);
        pushButtonDataSend->setObjectName(QString::fromUtf8("pushButtonDataSend"));
        sizePolicy1.setHeightForWidth(pushButtonDataSend->sizePolicy().hasHeightForWidth());
        pushButtonDataSend->setSizePolicy(sizePolicy1);
        pushButtonDataSend->setMinimumSize(QSize(100, 0));

        gridLayout_4->addWidget(pushButtonDataSend, 1, 4, 1, 1);

        lineEditFileSizeReceive = new QLineEdit(tab);
        lineEditFileSizeReceive->setObjectName(QString::fromUtf8("lineEditFileSizeReceive"));
        sizePolicy3.setHeightForWidth(lineEditFileSizeReceive->sizePolicy().hasHeightForWidth());
        lineEditFileSizeReceive->setSizePolicy(sizePolicy3);
        lineEditFileSizeReceive->setMinimumSize(QSize(200, 0));
        lineEditFileSizeReceive->setReadOnly(true);

        gridLayout_4->addWidget(lineEditFileSizeReceive, 9, 2, 1, 1);

        labelFileSizeReceive = new QLabel(tab);
        labelFileSizeReceive->setObjectName(QString::fromUtf8("labelFileSizeReceive"));

        gridLayout_4->addWidget(labelFileSizeReceive, 9, 0, 1, 1);

        labelPathTransmit = new QLabel(tab);
        labelPathTransmit->setObjectName(QString::fromUtf8("labelPathTransmit"));

        gridLayout_4->addWidget(labelPathTransmit, 1, 0, 1, 1);

        lineEditPathTransmit = new QLineEdit(tab);
        lineEditPathTransmit->setObjectName(QString::fromUtf8("lineEditPathTransmit"));
        lineEditPathTransmit->setReadOnly(true);

        gridLayout_4->addWidget(lineEditPathTransmit, 1, 2, 1, 1);

        labelFileNameReseive = new QLabel(tab);
        labelFileNameReseive->setObjectName(QString::fromUtf8("labelFileNameReseive"));

        gridLayout_4->addWidget(labelFileNameReseive, 8, 0, 1, 1);

        labelDataReceive = new QLabel(tab);
        labelDataReceive->setObjectName(QString::fromUtf8("labelDataReceive"));
        sizePolicy.setHeightForWidth(labelDataReceive->sizePolicy().hasHeightForWidth());
        labelDataReceive->setSizePolicy(sizePolicy);
        labelDataReceive->setAlignment(Qt::AlignCenter);

        gridLayout_4->addWidget(labelDataReceive, 6, 0, 1, 5);

        labelPathReceive = new QLabel(tab);
        labelPathReceive->setObjectName(QString::fromUtf8("labelPathReceive"));

        gridLayout_4->addWidget(labelPathReceive, 7, 0, 1, 1);

        line_3 = new QFrame(tab);
        line_3->setObjectName(QString::fromUtf8("line_3"));
        sizePolicy.setHeightForWidth(line_3->sizePolicy().hasHeightForWidth());
        line_3->setSizePolicy(sizePolicy);
        line_3->setFrameShadow(QFrame::Sunken);
        line_3->setLineWidth(1);
        line_3->setFrameShape(QFrame::HLine);

        gridLayout_4->addWidget(line_3, 5, 0, 1, 5);

        line_4 = new QFrame(tab);
        line_4->setObjectName(QString::fromUtf8("line_4"));
        line_4->setFrameShape(QFrame::HLine);
        line_4->setFrameShadow(QFrame::Sunken);

        gridLayout_4->addWidget(line_4, 12, 0, 1, 5);

        labelLog = new QLabel(tab);
        labelLog->setObjectName(QString::fromUtf8("labelLog"));
        labelLog->setAlignment(Qt::AlignCenter);

        gridLayout_4->addWidget(labelLog, 13, 0, 1, 5);

        lineEditFileSizeTransmit = new QLineEdit(tab);
        lineEditFileSizeTransmit->setObjectName(QString::fromUtf8("lineEditFileSizeTransmit"));
        sizePolicy3.setHeightForWidth(lineEditFileSizeTransmit->sizePolicy().hasHeightForWidth());
        lineEditFileSizeTransmit->setSizePolicy(sizePolicy3);
        lineEditFileSizeTransmit->setMinimumSize(QSize(200, 0));
        lineEditFileSizeTransmit->setReadOnly(true);

        gridLayout_4->addWidget(lineEditFileSizeTransmit, 2, 2, 1, 1);

        verticalSpacer_3 = new QSpacerItem(0, 10, QSizePolicy::Minimum, QSizePolicy::Fixed);

        gridLayout_4->addItem(verticalSpacer_3, 4, 2, 1, 1);

        verticalSpacer_2 = new QSpacerItem(20, 10, QSizePolicy::Minimum, QSizePolicy::Fixed);

        gridLayout_4->addItem(verticalSpacer_2, 11, 2, 1, 1);

        pushButtonDataToolReceive = new QPushButton(tab);
        pushButtonDataToolReceive->setObjectName(QString::fromUtf8("pushButtonDataToolReceive"));
        sizePolicy1.setHeightForWidth(pushButtonDataToolReceive->sizePolicy().hasHeightForWidth());
        pushButtonDataToolReceive->setSizePolicy(sizePolicy1);
        pushButtonDataToolReceive->setMinimumSize(QSize(50, 0));

        gridLayout_4->addWidget(pushButtonDataToolReceive, 7, 3, 1, 1);

        lineEditBytesReceived = new QLineEdit(tab);
        lineEditBytesReceived->setObjectName(QString::fromUtf8("lineEditBytesReceived"));
        sizePolicy3.setHeightForWidth(lineEditBytesReceived->sizePolicy().hasHeightForWidth());
        lineEditBytesReceived->setSizePolicy(sizePolicy3);
        lineEditBytesReceived->setMinimumSize(QSize(200, 0));

        gridLayout_4->addWidget(lineEditBytesReceived, 10, 2, 1, 1);

        labelBytesReceived = new QLabel(tab);
        labelBytesReceived->setObjectName(QString::fromUtf8("labelBytesReceived"));

        gridLayout_4->addWidget(labelBytesReceived, 10, 0, 1, 1);

        tabWidget->addTab(tab, QString());
        tab_2 = new QWidget();
        tab_2->setObjectName(QString::fromUtf8("tab_2"));
        gridLayout_2 = new QGridLayout(tab_2);
        gridLayout_2->setObjectName(QString::fromUtf8("gridLayout_2"));
        pushButtonMessageSend = new QPushButton(tab_2);
        pushButtonMessageSend->setObjectName(QString::fromUtf8("pushButtonMessageSend"));
        sizePolicy3.setHeightForWidth(pushButtonMessageSend->sizePolicy().hasHeightForWidth());
        pushButtonMessageSend->setSizePolicy(sizePolicy3);
        pushButtonMessageSend->setMinimumSize(QSize(100, 0));

        gridLayout_2->addWidget(pushButtonMessageSend, 2, 1, 1, 1);

        textEditMessage = new QTextEdit(tab_2);
        textEditMessage->setObjectName(QString::fromUtf8("textEditMessage"));
        textEditMessage->setReadOnly(true);
        textEditMessage->setTextInteractionFlags(Qt::NoTextInteraction);

        gridLayout_2->addWidget(textEditMessage, 1, 0, 1, 2);

        lineEditMessageSend = new QLineEdit(tab_2);
        lineEditMessageSend->setObjectName(QString::fromUtf8("lineEditMessageSend"));
        sizePolicy.setHeightForWidth(lineEditMessageSend->sizePolicy().hasHeightForWidth());
        lineEditMessageSend->setSizePolicy(sizePolicy);
        lineEditMessageSend->setMinimumSize(QSize(0, 0));
        lineEditMessageSend->setMaxLength(127);

        gridLayout_2->addWidget(lineEditMessageSend, 2, 0, 1, 1);

        pushButtonClear = new QPushButton(tab_2);
        pushButtonClear->setObjectName(QString::fromUtf8("pushButtonClear"));
        sizePolicy3.setHeightForWidth(pushButtonClear->sizePolicy().hasHeightForWidth());
        pushButtonClear->setSizePolicy(sizePolicy3);
        pushButtonClear->setMinimumSize(QSize(100, 0));

        gridLayout_2->addWidget(pushButtonClear, 0, 1, 1, 1);

        tabWidget->addTab(tab_2, QString());

        gridLayout->addWidget(tabWidget, 1, 0, 1, 1);

        gridLayout_3 = new QGridLayout();
        gridLayout_3->setObjectName(QString::fromUtf8("gridLayout_3"));
        pushButtonSave = new QPushButton(centralwidget);
        pushButtonSave->setObjectName(QString::fromUtf8("pushButtonSave"));
        pushButtonSave->setMinimumSize(QSize(0, 40));

        gridLayout_3->addWidget(pushButtonSave, 19, 0, 1, 3);

        labelChannel = new QLabel(centralwidget);
        labelChannel->setObjectName(QString::fromUtf8("labelChannel"));
        sizePolicy1.setHeightForWidth(labelChannel->sizePolicy().hasHeightForWidth());
        labelChannel->setSizePolicy(sizePolicy1);
        labelChannel->setMinimumSize(QSize(0, 0));

        gridLayout_3->addWidget(labelChannel, 10, 0, 1, 1);

        labelIdRx = new QLabel(centralwidget);
        labelIdRx->setObjectName(QString::fromUtf8("labelIdRx"));
        sizePolicy1.setHeightForWidth(labelIdRx->sizePolicy().hasHeightForWidth());
        labelIdRx->setSizePolicy(sizePolicy1);

        gridLayout_3->addWidget(labelIdRx, 17, 0, 1, 1);

        comboBoxIdTx = new QComboBox(centralwidget);
        comboBoxIdTx->setObjectName(QString::fromUtf8("comboBoxIdTx"));
        sizePolicy2.setHeightForWidth(comboBoxIdTx->sizePolicy().hasHeightForWidth());
        comboBoxIdTx->setSizePolicy(sizePolicy2);
        comboBoxIdTx->setMinimumSize(QSize(50, 0));

        gridLayout_3->addWidget(comboBoxIdTx, 18, 1, 1, 1);

        comboBoxModem = new QComboBox(centralwidget);
        comboBoxModem->setObjectName(QString::fromUtf8("comboBoxModem"));
        sizePolicy2.setHeightForWidth(comboBoxModem->sizePolicy().hasHeightForWidth());
        comboBoxModem->setSizePolicy(sizePolicy2);
        comboBoxModem->setMinimumSize(QSize(50, 0));

        gridLayout_3->addWidget(comboBoxModem, 11, 1, 1, 1);

        labelChannelConfig = new QLabel(centralwidget);
        labelChannelConfig->setObjectName(QString::fromUtf8("labelChannelConfig"));
        labelChannelConfig->setAlignment(Qt::AlignCenter);

        gridLayout_3->addWidget(labelChannelConfig, 9, 0, 1, 3);

        labelIdTx = new QLabel(centralwidget);
        labelIdTx->setObjectName(QString::fromUtf8("labelIdTx"));
        sizePolicy1.setHeightForWidth(labelIdTx->sizePolicy().hasHeightForWidth());
        labelIdTx->setSizePolicy(sizePolicy1);

        gridLayout_3->addWidget(labelIdTx, 18, 0, 1, 1);

        comboBoxIdRx = new QComboBox(centralwidget);
        comboBoxIdRx->setObjectName(QString::fromUtf8("comboBoxIdRx"));
        sizePolicy2.setHeightForWidth(comboBoxIdRx->sizePolicy().hasHeightForWidth());
        comboBoxIdRx->setSizePolicy(sizePolicy2);
        comboBoxIdRx->setMinimumSize(QSize(50, 0));

        gridLayout_3->addWidget(comboBoxIdRx, 17, 1, 1, 1);

        labelBattery = new QLabel(centralwidget);
        labelBattery->setObjectName(QString::fromUtf8("labelBattery"));
        labelBattery->setAlignment(Qt::AlignCenter);

        gridLayout_3->addWidget(labelBattery, 1, 0, 2, 3);

        radioButtonStateConnect = new QRadioButton(centralwidget);
        radioButtonStateConnect->setObjectName(QString::fromUtf8("radioButtonStateConnect"));
        radioButtonStateConnect->setStyleSheet(QString::fromUtf8("QRadioButton::indicator:unchecked\n"
" {\n"
"  image: url(:/images/radio_red.png);\n"
"}\n"
""));
        radioButtonStateConnect->setCheckable(false);

        gridLayout_3->addWidget(radioButtonStateConnect, 5, 0, 1, 3);

        labelModem = new QLabel(centralwidget);
        labelModem->setObjectName(QString::fromUtf8("labelModem"));
        sizePolicy1.setHeightForWidth(labelModem->sizePolicy().hasHeightForWidth());
        labelModem->setSizePolicy(sizePolicy1);

        gridLayout_3->addWidget(labelModem, 11, 0, 1, 1);

        labelAj = new QLabel(centralwidget);
        labelAj->setObjectName(QString::fromUtf8("labelAj"));
        sizePolicy1.setHeightForWidth(labelAj->sizePolicy().hasHeightForWidth());
        labelAj->setSizePolicy(sizePolicy1);

        gridLayout_3->addWidget(labelAj, 15, 0, 1, 1);

        comboBoxMode = new QComboBox(centralwidget);
        comboBoxMode->setObjectName(QString::fromUtf8("comboBoxMode"));
        sizePolicy2.setHeightForWidth(comboBoxMode->sizePolicy().hasHeightForWidth());
        comboBoxMode->setSizePolicy(sizePolicy2);
        comboBoxMode->setMinimumSize(QSize(50, 0));

        gridLayout_3->addWidget(comboBoxMode, 14, 1, 1, 1);

        labelFrequency = new QLabel(centralwidget);
        labelFrequency->setObjectName(QString::fromUtf8("labelFrequency"));
        sizePolicy1.setHeightForWidth(labelFrequency->sizePolicy().hasHeightForWidth());
        labelFrequency->setSizePolicy(sizePolicy1);

        gridLayout_3->addWidget(labelFrequency, 12, 0, 1, 1);

        labelMode = new QLabel(centralwidget);
        labelMode->setObjectName(QString::fromUtf8("labelMode"));
        sizePolicy1.setHeightForWidth(labelMode->sizePolicy().hasHeightForWidth());
        labelMode->setSizePolicy(sizePolicy1);

        gridLayout_3->addWidget(labelMode, 14, 0, 1, 1);

        line_2 = new QFrame(centralwidget);
        line_2->setObjectName(QString::fromUtf8("line_2"));
        line_2->setFrameShape(QFrame::HLine);
        line_2->setFrameShadow(QFrame::Sunken);

        gridLayout_3->addWidget(line_2, 20, 0, 1, 3);

        line_6 = new QFrame(centralwidget);
        line_6->setObjectName(QString::fromUtf8("line_6"));
        line_6->setFrameShape(QFrame::HLine);
        line_6->setFrameShadow(QFrame::Sunken);

        gridLayout_3->addWidget(line_6, 4, 0, 1, 3);

        inputIp = new IPCtrl(centralwidget);
        inputIp->setObjectName(QString::fromUtf8("inputIp"));
        sizePolicy3.setHeightForWidth(inputIp->sizePolicy().hasHeightForWidth());
        inputIp->setSizePolicy(sizePolicy3);
        inputIp->setMinimumSize(QSize(200, 20));

        gridLayout_3->addWidget(inputIp, 6, 0, 1, 3);

        comboBoxChannel = new QComboBox(centralwidget);
        comboBoxChannel->setObjectName(QString::fromUtf8("comboBoxChannel"));
        sizePolicy2.setHeightForWidth(comboBoxChannel->sizePolicy().hasHeightForWidth());
        comboBoxChannel->setSizePolicy(sizePolicy2);
        comboBoxChannel->setMinimumSize(QSize(50, 0));
        comboBoxChannel->setStyleSheet(QString::fromUtf8(""));

        gridLayout_3->addWidget(comboBoxChannel, 10, 1, 1, 1);

        progressBar = new QProgressBar(centralwidget);
        progressBar->setObjectName(QString::fromUtf8("progressBar"));
        sizePolicy.setHeightForWidth(progressBar->sizePolicy().hasHeightForWidth());
        progressBar->setSizePolicy(sizePolicy);
        progressBar->setValue(0);

        gridLayout_3->addWidget(progressBar, 22, 0, 1, 3);

        line = new QFrame(centralwidget);
        line->setObjectName(QString::fromUtf8("line"));
        line->setFrameShape(QFrame::HLine);
        line->setFrameShadow(QFrame::Sunken);

        gridLayout_3->addWidget(line, 8, 0, 1, 3);

        labelPower = new QLabel(centralwidget);
        labelPower->setObjectName(QString::fromUtf8("labelPower"));
        sizePolicy1.setHeightForWidth(labelPower->sizePolicy().hasHeightForWidth());
        labelPower->setSizePolicy(sizePolicy1);

        gridLayout_3->addWidget(labelPower, 13, 0, 1, 1);

        comboBoxPower = new QComboBox(centralwidget);
        comboBoxPower->setObjectName(QString::fromUtf8("comboBoxPower"));
        sizePolicy2.setHeightForWidth(comboBoxPower->sizePolicy().hasHeightForWidth());
        comboBoxPower->setSizePolicy(sizePolicy2);
        comboBoxPower->setMinimumSize(QSize(50, 0));

        gridLayout_3->addWidget(comboBoxPower, 13, 1, 1, 1);

        lineEditProcess = new QLineEdit(centralwidget);
        lineEditProcess->setObjectName(QString::fromUtf8("lineEditProcess"));
        lineEditProcess->setReadOnly(true);

        gridLayout_3->addWidget(lineEditProcess, 21, 0, 1, 3);

        lineEditFrequency = new QLineEdit(centralwidget);
        lineEditFrequency->setObjectName(QString::fromUtf8("lineEditFrequency"));
        QSizePolicy sizePolicy4(QSizePolicy::Ignored, QSizePolicy::Fixed);
        sizePolicy4.setHorizontalStretch(0);
        sizePolicy4.setVerticalStretch(0);
        sizePolicy4.setHeightForWidth(lineEditFrequency->sizePolicy().hasHeightForWidth());
        lineEditFrequency->setSizePolicy(sizePolicy4);
        lineEditFrequency->setMinimumSize(QSize(0, 0));
        lineEditFrequency->setMaxLength(7);
        lineEditFrequency->setAlignment(Qt::AlignCenter);

        gridLayout_3->addWidget(lineEditFrequency, 12, 1, 1, 1);

        progressBarBattery = new QProgressBar(centralwidget);
        progressBarBattery->setObjectName(QString::fromUtf8("progressBarBattery"));
        progressBarBattery->setValue(0);

        gridLayout_3->addWidget(progressBarBattery, 3, 0, 1, 3);

        labelKHZ = new QLabel(centralwidget);
        labelKHZ->setObjectName(QString::fromUtf8("labelKHZ"));
        sizePolicy3.setHeightForWidth(labelKHZ->sizePolicy().hasHeightForWidth());
        labelKHZ->setSizePolicy(sizePolicy3);
        labelKHZ->setMinimumSize(QSize(0, 0));

        gridLayout_3->addWidget(labelKHZ, 12, 2, 1, 1);

        labelKey = new QLabel(centralwidget);
        labelKey->setObjectName(QString::fromUtf8("labelKey"));
        sizePolicy1.setHeightForWidth(labelKey->sizePolicy().hasHeightForWidth());
        labelKey->setSizePolicy(sizePolicy1);

        gridLayout_3->addWidget(labelKey, 16, 0, 1, 1);

        comboBoxKey = new QComboBox(centralwidget);
        comboBoxKey->setObjectName(QString::fromUtf8("comboBoxKey"));
        sizePolicy2.setHeightForWidth(comboBoxKey->sizePolicy().hasHeightForWidth());
        comboBoxKey->setSizePolicy(sizePolicy2);
        comboBoxKey->setMinimumSize(QSize(50, 0));

        gridLayout_3->addWidget(comboBoxKey, 16, 1, 1, 1);

        pushButtonConnect = new QPushButton(centralwidget);
        pushButtonConnect->setObjectName(QString::fromUtf8("pushButtonConnect"));
        sizePolicy2.setHeightForWidth(pushButtonConnect->sizePolicy().hasHeightForWidth());
        pushButtonConnect->setSizePolicy(sizePolicy2);
        pushButtonConnect->setMinimumSize(QSize(0, 40));

        gridLayout_3->addWidget(pushButtonConnect, 7, 0, 1, 3);

        comboBoxAj = new QComboBox(centralwidget);
        comboBoxAj->setObjectName(QString::fromUtf8("comboBoxAj"));
        sizePolicy2.setHeightForWidth(comboBoxAj->sizePolicy().hasHeightForWidth());
        comboBoxAj->setSizePolicy(sizePolicy2);
        comboBoxAj->setMinimumSize(QSize(50, 0));

        gridLayout_3->addWidget(comboBoxAj, 15, 1, 1, 1);

        lineEditSpeed = new QLineEdit(centralwidget);
        lineEditSpeed->setObjectName(QString::fromUtf8("lineEditSpeed"));
        lineEditSpeed->setDragEnabled(false);
        lineEditSpeed->setReadOnly(true);

        gridLayout_3->addWidget(lineEditSpeed, 23, 0, 1, 3);

        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout_3->addItem(verticalSpacer, 24, 0, 1, 1);


        gridLayout->addLayout(gridLayout_3, 1, 1, 1, 1);

        View->setCentralWidget(centralwidget);

        retranslateUi(View);

        tabWidget->setCurrentIndex(1);


        QMetaObject::connectSlotsByName(View);
    } // setupUi

    void retranslateUi(QMainWindow *View)
    {
        View->setWindowTitle(QCoreApplication::translate("View", "View", nullptr));
        labelDataTansmit->setText(QCoreApplication::translate("View", "Transmit", nullptr));
        pushButtonDataCancel->setText(QCoreApplication::translate("View", "Cancel", nullptr));
        labelFileSizeTransmit->setText(QCoreApplication::translate("View", "File size", nullptr));
        labelBytesSent->setText(QCoreApplication::translate("View", "Bytes sent", nullptr));
        pushButtonDataToolTransmit->setText(QCoreApplication::translate("View", "...", nullptr));
        pushButtonDataSend->setText(QCoreApplication::translate("View", "Send", nullptr));
        labelFileSizeReceive->setText(QCoreApplication::translate("View", "File size", nullptr));
        labelPathTransmit->setText(QCoreApplication::translate("View", "Path", nullptr));
        labelFileNameReseive->setText(QCoreApplication::translate("View", "File name", nullptr));
        labelDataReceive->setText(QCoreApplication::translate("View", "Receive", nullptr));
        labelPathReceive->setText(QCoreApplication::translate("View", "Path", nullptr));
        labelLog->setText(QCoreApplication::translate("View", "Log", nullptr));
        pushButtonDataToolReceive->setText(QCoreApplication::translate("View", "...", nullptr));
        labelBytesReceived->setText(QCoreApplication::translate("View", "Bytes reseived", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(tab), QCoreApplication::translate("View", "Data", nullptr));
        pushButtonMessageSend->setText(QCoreApplication::translate("View", "Send", nullptr));
        pushButtonClear->setText(QCoreApplication::translate("View", "Clear", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(tab_2), QCoreApplication::translate("View", "Message", nullptr));
        pushButtonSave->setText(QCoreApplication::translate("View", "Save", nullptr));
        labelChannel->setText(QCoreApplication::translate("View", "Channel", nullptr));
        labelIdRx->setText(QCoreApplication::translate("View", "IDrx", nullptr));
        labelChannelConfig->setText(QCoreApplication::translate("View", "Channel configuration", nullptr));
        labelIdTx->setText(QCoreApplication::translate("View", "IDtx", nullptr));
        labelBattery->setText(QCoreApplication::translate("View", "Battery", nullptr));
        radioButtonStateConnect->setText(QCoreApplication::translate("View", "Not Connect", nullptr));
        labelModem->setText(QCoreApplication::translate("View", "Modem", nullptr));
        labelAj->setText(QCoreApplication::translate("View", "Aj", nullptr));
        labelFrequency->setText(QCoreApplication::translate("View", "Frequency", nullptr));
        labelMode->setText(QCoreApplication::translate("View", "Mode", nullptr));
        labelPower->setText(QCoreApplication::translate("View", "Power", nullptr));
        lineEditProcess->setText(QCoreApplication::translate("View", "Process: Idle", nullptr));
        labelKHZ->setText(QCoreApplication::translate("View", "kHz", nullptr));
        labelKey->setText(QCoreApplication::translate("View", "Key", nullptr));
        pushButtonConnect->setText(QCoreApplication::translate("View", "Connect", nullptr));
        lineEditSpeed->setText(QCoreApplication::translate("View", "Speed: ", nullptr));
    } // retranslateUi

};

namespace Ui {
    class View: public Ui_View {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_VIEW_H
